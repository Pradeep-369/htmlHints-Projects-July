// import React, { Component } from "react";
import React from "react";
import "./App.css";
class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fields: {},
      errors: {},
    };
  }

  handleValidation() {
    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;

    //Name
    if (!fields["name"]) {
      formIsValid = false;
      errors["name"] = "Cannot be empty";
    }

    if (typeof fields["name"] !== "undefined") {
      if (!fields["name"].match(/^[a-zA-Z]+$/)) {
        formIsValid = false;
        errors["name"] = "Name Only  be  letters";
      }
    }

    if (!fields["userName"]) {
      formIsValid = false;
      errors["userName"] = "User Name Cannot be empty";
    }

    //Email
    if (!fields["email"]) {
      formIsValid = false;
      errors["email"] = "Cannot be empty";
    }

    if (typeof fields["email"] !== "undefined") {
      let lastAtPos = fields["email"].lastIndexOf("@");
      let lastDotPos = fields["email"].lastIndexOf(".");

      if (
        !(
          lastAtPos < lastDotPos &&
          lastAtPos > 0 &&
          fields["email"].indexOf("@@") === -1 &&
          lastDotPos > 2 &&
          fields["email"].length - lastDotPos > 2
        )
      ) {
        formIsValid = false;
        errors["email"] = "Email is not valid";
      }
    }
    // Password

    if (!fields["password"]) {
      formIsValid = false;
      errors["password"] = "Password cannot be empty";
    }
    if (fields["password"] < 8) {
      formIsValid = false;
      errors["password"] =
        "Password Length Must be  less than are equal to 8 characters ";
    }

    if (fields["password"] !== fields["passwordCopy"]) {
      formIsValid = false;
      errors["passwordCopy"] = "Password Doesn't Match ";
    }

    // Checkbox

    this.setState({ errors: errors });
    return formIsValid;
  }

  contactSubmit(e) {
    e.preventDefault();
    if (this.handleValidation()) {
      alert("Form submitted :) ");
    } else {
      alert("You Have Some Errors in The input");
    }
  }

  handleChange(field, e) {
    let fields = this.state.fields;
    fields[field] = e.target.value;
    this.setState({ fields });
  }

  render() {
    return (
      <div className="container">
        <div className="hero-image"></div>
        <div className="form-container">
          <form
            action="#"
            className="form__container2"
            onSubmit={this.contactSubmit.bind(this)}
          >
            <h2 className="form-title">Create Account</h2>
            <div>
              <label htmlFor="fullName">
                <small>Full Name</small>
              </label>
              <br />
              <input
                type="text"
                name="Full Name "
                id="fullName"
                placeholder="Name.."
                creactref={"name"}
                onChange={this.handleChange.bind(this, "name")}
                value={this.state.fields["name"]}
              />
              <small className="error">{this.state.errors["name"]}</small>
            </div>
            <div>
              <label htmlFor="email">
                <small>Email</small>
              </label>
              <br />
              <input
                createrefs="email"
                type="email"
                name="User email"
                id="email"
                placeholder="Email address..."
                onChange={this.handleChange.bind(this, "email")}
                value={this.state.fields["email"]}
              />
              <small className="error">{this.state.errors["email"]}</small>
            </div>
            <div>
              <label htmlFor="userName">
                <small>User Name</small>
              </label>
              <br />
              <input
                createrefs="name"
                type="text"
                name="User Name "
                id="userName"
                placeholder="Username..."
                onChange={this.handleChange.bind(this, "userName")}
                value={this.state.fields["userName"]}
              />
              <small className="error">{this.state.errors["userName"]}</small>
            </div>
            <div>
              <label htmlFor="password">
                <small>User Password</small>
              </label>
              <br />
              <input
                createrefs="password"
                type="password"
                name="User Password "
                id="password"
                placeholder="****************"
                onChange={this.handleChange.bind(this, "password")}
                value={this.state.fields["password"]}
              />
              <small className="error">{this.state.errors["password"]}</small>
            </div>
            <div>
              <label htmlFor="Repeat-password">
                <small>Repeat Password</small>
              </label>
              <br />
              <input
                createrefs="passwordCopy"
                type="password"
                name="Repeat Password "
                id="Repeat-password"
                placeholder="****************"
                onChange={this.handleChange.bind(this, "passwordCopy")}
                value={this.state.fields["passwordCopy"]}
              />
              <small className="error">
                {this.state.errors["passwordCopy"]}
              </small>
            </div>
            <div>
              <input
                createrefs="check"
                type="checkbox"
                name="Terms&Conditions"
                id="terms"
              />
              <label htmlFor="terms">
                <small> I agree to the Terms of User </small>
              </label>{" "}
              <br />
              <small id="agreement-error">
                {" "}
                Make Sure Before Submitting form You Agree With The Terms and
                Conditions
              </small>
            </div>
            <div className="btn__container">
              <input type="submit" value="Sign up" className="submit-btn" />
              <button className="sign_in_btn">
                <a
                  href="https://unsplash.com/s/photos/login"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Sign In
                  <i className="fa fa-arrow-right" aria-hidden="true"></i>
                </a>
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }
}

export default App;

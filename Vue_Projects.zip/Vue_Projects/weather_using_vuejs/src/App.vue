<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
  <!-- <HelloWorld msg="Counter App" />
  <button @click="decrease()">-</button>
  <div>{{ count }}</div>
  <button @click="add()">+</button> -->

  <section class="weather-block">
    
    <div class="weather__body">
      <h2 class="weather__title">{{city}}</h2>
      <!-- <ReactAnimatedWeather
          icon={visible && sky}
          color={visible && defaults.color}
          size={visible && defaults.size}
          animate={visible && defaults.animate}
        /> -->
      <h3 class="weather__subtitle">IN</h3>
      <h2 class="weather__temp">{{temp}}°C</h2>
    </div>
  </section>
</template>

<script>
// import HelloWorld from "./components/HelloWorld.vue";

export default {
  name: "App",
  components: {
    // HelloWorld,
  },
  data() {
    return {
      count: 1,
      city: "chennai",
      temp: "loading temp",
    };
  },
  created() {
    fetch(`https://api.openweathermap.org/data/2.5/weather?q=york&appid=9c7c83cb9a1f60d178bd6ec2378a1f80&units=metric`)
      .then((response) => response.json())
      .then((data) => {
        (this.city = data.name), (this.temp = data.main.temp);
      });
  },
  // methods: {
  //   add() {
  //     (this.count = this.count + 1), console.log(this.city, this.temp);
  //   },
  //   decrease() {
  //     this.count = this.count - 1;
  //   },
  // },
};
</script>

<style>
/* #app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
} */

html {
  box-sizing: border-box;
}
*,
body,
::before,
::after {
  box-sizing: inherit;
  padding: 0;
  margin: 0;
}
body {
  width: 100vw;
  height: 100vh;
  display: grid;
  place-items: center;
  font-family: Helvetica, sans-serif;
  
}

.weather-block {
  width: 50vw;  
  height: 400px;
  padding: 10px;
  color: white;
  border-radius: 20px;
  position: relative;
   background: url("https://images.unsplash.com/photo-1533371452382-d45a9da51ad9?ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTh8fG9jZWFuJTIwc2t5fGVufDB8fDB8fA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60")
    center/cover no-repeat;
    box-shadow: 0px 0px 40px rgba(0,0,0,0.5),10px 0px 40px rgba(0,0,0,0.5);
}

.weather-body {
  width: 100%;
  height: 100%;
}
.weather__title {
  font-size: 29px;
  margin: 10px;
}
.weather__subtitle {
  font-size: 19px;
  margin: 10px;
}
.weather__temp {
  position: absolute;
  right: 0;
  bottom: 0;
  font-size: 45px;
  margin: 10px;
}
</style>

import React from "react";
import ReactAnimatedWeather from "react-animated-weather";
const defaults = {
  icon: "CLEAR_DAY",
  color: "white",
  size: 100,
  animate: true,
};
function WeatherInfos(props) {
  var weatherIcon = null;
  switch (props.weatherName) {
    case "Haze":
      weatherIcon = "CLOUDY";
      break;
    case "Rain":
      weatherIcon = "RAIN";
      break;
    case "RAIN":
      weatherIcon = "CLOUDY";
      break;
    case "Clouds":
      weatherIcon = "CLOUDY";
      break;
    default:
      weatherIcon = "CLEAR_DAY";
  }
  return (
    <React.Fragment>
      <div className="col-4 side-bg py-3">
        <h2 className="card-title text-center my-2">
          {" "}
          <ReactAnimatedWeather
            icon={weatherIcon}
            color={defaults.color}
            size={defaults.size}
            animate={defaults.animate}
          />
        </h2>
        <h2 className="text-white p-3 text-center">{props.weatherName}</h2>
        <div className="d-flex px-4 py-3 flex-wrap gap-2">
          <div className="d-flex col-12 justify-content-between">
            <div className="text-white ">
              <h5>Humidity</h5>
            </div>
            <div className="text-white ">
              {" "}
              <h6>{props.humidity}%</h6>
            </div>
          </div>
          <div className="d-flex col-12 justify-content-between">
            <div className="text-white ">
              <h5>Visibility</h5>
            </div>
            <div className="text-white ">
              {" "}
              <h6>{props.visibility}mi</h6>
            </div>
          </div>
          <div className="d-flex col-12 justify-content-between">
            <div className="text-white ">
              <h5>Wind Speed </h5>
            </div>
            <div className="text-white ">
              {" "}
              <h6>{props.wind}Km/h</h6>
            </div>
          </div>
          <div className="d-flex col-12 justify-content-between">
            <div className="text-white ">
              <h5>Feels Like</h5>
            </div>
            <div className="text-white ">
              {" "}
              <h6>{props.feelsLike}°C</h6>
            </div>
          </div>
          <div className="d-flex col-12 justify-content-between">
            <div className="text-white ">
              <h5>Max Temp</h5>
            </div>
            <div className="text-white ">
              {" "}
              <h6>{props.maxTemp} °C</h6>
            </div>
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

export default WeatherInfos;

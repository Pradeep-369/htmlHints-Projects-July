import React, { Component } from "react";

// import reactDom from "react-dom";
import WeatherInfos from "./weatherInfos";
import Clock from "react-live-clock";

import "./App.css";
class App extends React.Component {
  state = {
    latitude: null,
    longitude: null,
    temp: null,
    locationName: null,
    country: null,
    humidity: null,
    visibility: null,
    wind: null,
    maxTemp: null,
    feelsLike: null,
    weatherName: null,
    visible: false,
  };
  componentDidMount() {
    this.getPosition().then((position) => {
      console.log(position.coords.latitude);
      this.setState({ latitude: position.coords.latitude });
      this.getWeather(position.coords.latitude, position.coords.longitude);
    });
  }

  getPosition = () => {
    return new Promise(function (resolve, reject) {
      navigator.geolocation.getCurrentPosition(resolve, reject);
    });
  };
  getWeather = async (latitude, longitude) => {
    const api = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${latitude}&lon=${longitude}&appid=9c7c83cb9a1f60d178bd6ec2378a1f80&units=metric`
    );
    const data = await api.json();
    console.log(data);
    this.setState({
      temp: data.main.temp,
      locationName: data.name,
      country: data.sys.country,
      humidity: data.main.humidity,
      visibility: data.visibility,
      wind: data.wind.speed,
      maxTemp: data.main.temp_max,
      feelsLike: data.main.feels_like,
      weatherName: data.weather[0].main,
      visible: true,
    });
  };
  render() {
    return (
      <React.Fragment>
        <div className="col-8 d-flex justify-content-center py-5 margin-auto ">
          <div className="col-6 weather-background  d-flex flex-wrap py-3 p-3">
            <div className="col-12">
              <h2 className="text-white m-0">
                {" "}
                {this.state.visible ? this.state.locationName : "Loading...."}
              </h2>
              <p className="text-white">
                {" "}
                {this.state.visible ? this.state.country : "Loading"}
              </p>
            </div>
            <div className="col-12 mt-auto d-flex justify-content-between">
              <div className="my-auto ">
                <h2 className="text-white m-0 ">
                  <Clock format={"HH:mm:ss"} ticking={true} />
                </h2>
                <p className="text-white m-0">
                  {" "}
                  <Clock date={""} format={"dddd, MMMM DD, YYYY"} />
                </p>
              </div>
              <div className="ml-auto">
                <h1 className="text-white">
                  {this.state.visible ? this.state.temp : "Loading"}°C
                </h1>
              </div>
            </div>
          </div>
          <WeatherInfos
            humidity={this.state.humidity}
            visibility={this.state.visibility}
            wind={this.state.wind}
            feelsLike={this.state.feelsLike}
            maxTemp={this.state.maxTemp}
            weatherName={this.state.weatherName}
          />
        </div>
      </React.Fragment>
    );
  }
}

export default App;

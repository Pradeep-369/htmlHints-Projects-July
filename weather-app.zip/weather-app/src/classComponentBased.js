import React, { Component } from "react";
import "./App.css";

class App extends Component {
  state = {
    city: "Mumbai ",
    temp: 0,
    country: "IN",
    visible: false,
  };
  componentDidMount() {
    fetch(
      "https://api.openweathermap.org/data/2.5/weather?q=york&appid=9c7c83cb9a1f60d178bd6ec2378a1f80&units=metric"
    )
      .then((response) => response.json())
      .then((data) => {
        console.log(data);
        this.setState({
          city: data.name,
          temp: data.main.temp,
          country: data.sys.country,
          visible: true,
        });
      });
  }

  render() {
    return (
      <section className="weather-block">
        <div className="weather__body">
          <h2 className="weather__title">
            New {this.state.visible ? this.state.city : "Loading"} City
          </h2>
          <h3 className="weather__subtitle">{this.state.country}</h3>
          <h2 className="weather__temp">{this.state.temp}°C</h2>
        </div>
      </section>
    );
  }
}
// 9c7c83cb9a1f60d178bd6ec2378a1f80
export default App;

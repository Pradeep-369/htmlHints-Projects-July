import React from "react";
import { useState, useEffect } from "react";
import ReactAnimatedWeather from "react-animated-weather";
import axios from "axios";
import "./App.css";
let sky;

function App() {
  const [weather, setWeather] = useState([]);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    axios
      .get(
        "https://api.openweathermap.org/data/2.5/weather?q=york&appid=9c7c83cb9a1f60d178bd6ec2378a1f80&units=metric"
      )
      .then((res) => {
        sky = res.data.weather[0].main;
        console.log(sky);

        switch (sky) {
          case "cloudy":
            sky = "PARTLY_CLOUDY_DAY";
            break;
          case "Clouds":
            sky = "CLOUDY";
            break;
          case "rain":
            sky = "RAIN";
            break;
          case "Sleet":
            sky = "SLEET";
            break;
          case "Snow":
            sky = "SNOW";
            break;
          case "WIND":
            sky = "WIND";
            break;
          case "fog":
            sky = '"FOG"';
            break;

          default:
            sky = "CLEAR_DAY";
        }
        setWeather(res.data);
        console.log(res.data);
        setVisible(true);
      });
  }, []);

  const defaults = {
    icon: sky,
    color: "goldenrod",
    size: 50,
    animate: true,
  };
  console.log(sky);
  return (
    <section className="weather-block">
      <div className="weather__body">
        <h2 className="weather__title">New {visible && weather.name} City </h2>
        <ReactAnimatedWeather
          icon={visible && sky}
          color={visible && defaults.color}
          size={visible && defaults.size}
          animate={visible && defaults.animate}
        />
        <h3 className="weather__subtitle">IN</h3>
        <h2 className="weather__temp">{visible && weather.main.temp}°C</h2>
      </div>
    </section>
  );
}

export default App;
